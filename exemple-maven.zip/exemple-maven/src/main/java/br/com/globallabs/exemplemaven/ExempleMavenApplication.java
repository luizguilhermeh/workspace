package br.com.globallabs.exemplemaven;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExempleMavenApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExempleMavenApplication.class, args);
	}

}
