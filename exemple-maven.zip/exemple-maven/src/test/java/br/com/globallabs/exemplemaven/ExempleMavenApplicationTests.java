package br.com.globallabs.exemplemaven;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExempleMavenApplicationTests {

	@Test
	void contextLoads() {
	}

}
