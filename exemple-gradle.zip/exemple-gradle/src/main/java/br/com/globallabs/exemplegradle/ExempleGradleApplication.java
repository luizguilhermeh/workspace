package br.com.globallabs.exemplegradle;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExempleGradleApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExempleGradleApplication.class, args);
	}

}
